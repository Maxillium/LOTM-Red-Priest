# LOTM-Red-Priest
This is the code for the Red Priest pathway and my way of helping original creator.
